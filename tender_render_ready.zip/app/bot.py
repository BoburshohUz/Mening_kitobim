# placeholder; main app is app/main.py
print('Run: uvicorn app.main:app --host 0.0.0.0 --port 8080')
